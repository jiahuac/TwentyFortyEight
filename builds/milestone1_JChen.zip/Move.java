public class Move {
    public static final int[] UP = {0, 0, 1};
    public static final int[] DOWN = {0, 0, -1};
    public static final int[] LEFT = {0, -1, 0};
    public static final int[] RIGHT = {0, 1, 0};
    public static final int[] FORWARD = {1, 0, 0};
    public static final int[] BACKWARD = {-1, 0, 0};
}
