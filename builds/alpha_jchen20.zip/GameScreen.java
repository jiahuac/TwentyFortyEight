import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;

/**
 * GameScreen class for 3D-2048 game
 * Graphics and drawing for 2048 game
 * @author Jiahua Chen
 * @version alph-1.0 05.05.2019
 */

public class GameScreen extends JPanel
{
    private Grid myGrid;

    public GameScreen(Grid grid)
    {
        myGrid = grid;
        this.addKeyListener(new GameKeyHandler(myGrid, this));
        this.setFocusable(true);
        this.requestFocusInWindow();
    }

    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        for (Tile t : myGrid.getTiles())
        {
            t.drawMe(g2);
        }
        g2.drawString("Score: " + Integer.toString(myGrid.getScore()), 50, 50);
    }
}